import darkPool

MODEL_POOL_SIZE = 8
GREEDY = False

PORT = '18500'
#LOG_LEVEL = 'warning'
LOG_LEVEL = 'debug'

if __name__ == '__main__':
    #main()
    darkPool.startServer(port = PORT, model_pool_size = MODEL_POOL_SIZE, greedy = GREEDY, log_level = LOG_LEVEL)


