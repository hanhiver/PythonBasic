
###############################
'''
Usage of the darkPool module. 

In server side:
    1. Import darkPool. 
    2. Call the function startServer() to start the server listen the certain PORT. 

In client side: 
    1. Import darkPool. 
    2. Call the clientInit() to establish connection to the model server. 
    3. clientDetect(client, image) function will send image to model for prediction. 
       (client is the return value of clientInit(), image is the cv2 format image) 

Dong Han
2019.01.23
'''
###############################

import os
import multiprocessing, threading
import cv2
import numpy as np 
import logging
from pprint import pprint
from time import time, sleep

import grpc
import data_pb2, data_pb2_grpc
import pickle, base64
from concurrent import futures

import dnet
import loggerManager

_ONE_DAY_IN_SECONDS = 60 * 60 * 24
_HOST = 'localhost'
_PORT = '18500'

# Server send message size. This need to contain the prediction output. 
_SERVER_SEND_MSG_SIZE = 416 * 416 * 3

# Server recv message size. This will contain the image for prediction.  
_SERVER_RECV_MSG_SIZE = 1000 * 800 * 3

# How many processes can be started in one GPU. 
_MAX_PROCESSES_PER_GPU = 7

process_id = None
process_gpu_id = None
logger_manager = None
work_logger = None

#####################
# Server part code. #
#####################

'''
Using the multiprocessing model to start moder server. 
'''

'''
Model Initialization. 
'''
def initialModel(pool_info, lock, logger, greedy = True):

    global process_id
    global process_gpu_id
    #global logger_manager
    global work_logger

    work_logger = logger
    #work_logger = logger_manager.get_logger('ModelServer.Worker')

    # Get process lock to handle the pool_info structure. 
    lock.acquire()
    
    # If there are more than one GPU in the system. 
    if pool_info['GPU_NUMBER'] > 1:
        # Set GPU affinity for current process. 
        if greedy:
            # If greedy is True, start model processes as many as possible to one GPU.  
            for i in range((pool_info['GPU_NUMBER'] - 1), -1, -1):
                if pool_info['GPU_AFFINITY'][i] < pool_info['MAX_PROCESSES_PER_GPU']:
                    process_gpu_id = i
                    break
        else:
            # If greedy is False, start model processes balanced to each GPU. 
            process_gpu_id = pool_info['GPU_AFFINITY'].index(min(pool_info['GPU_AFFINITY']))
    
        pool_info['GPU_AFFINITY'][process_gpu_id] += 1
        #os.putenv('CUDA_VISIBLE_DEVICES', '0')
        os.putenv('CUDA_VISIBLE_DEVICES', str(process_gpu_id))
        #print('GPU_AFFINITY', pool_info['GPU_AFFINITY'])
        work_logger.info('GPU enabled, start worker in GPU {}'.format(process_gpu_id))

    process_id = len(pool_info['PROCESSES_LIST'])

    pool_info['PROCESSES_LIST'].append(os.getpid())
    
    # Release the lock after pool_info update. 
    lock.release()

    # Model process initialization. 
    dnet.initModel()

    work_logger.info('WORKER: {:2d}, PID: {} Initialed. '.format(process_id, os.getpid()))

'''
Feed image to the model. 

image: 
    cv2 images. 

Return: 
    Queue of model output. Use .get() to get the model output. 

'''
def feedImage(image):
    global process_id
    global work_logger

    start = time()
    model_out = dnet.dnet_detect_image(dnet.netMain, dnet.metaMain, image, thresh=.2)

    work_logger.debug('WORKER: {:2d}, complet a task in {:.5f} seconds.'.format(process_id, time() - start))

    return model_out


'''
Model server process. 
'''
class ServerProcessPool(object):
    def __init__(self, pool_size = 1, greedy = True):
        global logger_manager
        self.logger = logger_manager.get_logger('ModelServer')
        
        self.lock = multiprocessing.Lock()
        self.manager = multiprocessing.Manager()
        self.pool_info = self.manager.dict()
        self.process_list = self.manager.list()
        self.gpu_affinity = self.manager.list()

        self.logger.info('ServerProcessPool initialize.')

        # Lock the process to make sure we finish the main process initialzation. 
        self.lock.acquire()

        with os.popen('nvidia-smi -L | grep GPU | wc -l') as command_pipe:
            gpu_number = command_pipe.read()
            gpu_number = int(gpu_number)
            #print('GPU NUMBER:', gpu_number)

        self.logger.info('{} GPU found in the system. '.format(gpu_number))

        # If there is GPU in the system, consider the GPU_AFFINITY, 
        # else, the model will start in CPU side, we don't need to consider the _MAX_PROCESSES_PER_GPU limit. 
        if gpu_number:
            if pool_size > gpu_number * _MAX_PROCESSES_PER_GPU:
                self.logger.critical('Cannot start {} processes in {} GPU system with _MAX_PROCESSES_PER_GPU setting {}.'.format(
                        pool_size, gpu_number, _MAX_PROCESSES_PER_GPU))
                self.logger.critical('Server Stop.')
                exit(-1)

        self.pool_info['POOL_SIZE'] = pool_size
        self.pool_info['PROCESSES_LIST'] = self.process_list
        self.pool_info['GPU_NUMBER'] = gpu_number
        self.pool_info['MAX_PROCESSES_PER_GPU'] = _MAX_PROCESSES_PER_GPU
        self.pool_info['GPU_AFFINITY'] = self.gpu_affinity

        for i in range(gpu_number):
            self.pool_info['GPU_AFFINITY'].append(0)

        self.logger.info('PROCESSES_LIST: '.format(str(self.pool_info['PROCESSES_LIST'])))
        self.logger.info('GPU_AFFINITY: '.format(str(self.pool_info['GPU_AFFINITY'])))

        # Release the lock to start sub-processes' initialization. 
        self.lock.release()

        self.pool = multiprocessing.Pool(processes = pool_size, 
                                         initializer = initialModel,
                                         initargs = (self.pool_info, self.lock, self.logger, greedy))

        self.logger.info('ServerProcessPool initilized. ')

    def __del__(self):
        self.pool.close()
        self.pool.join()
        self.logger.info('ServerProcessPool deleted. ')

    def predictImage(self, image_str):
        
        start = time()

        # Decode the pickle_str from grpc message. 
        pickle_str = base64.b64decode(image_str)

        # Decode the image_encode from the pickle_str 
        image_encode = pickle.loads(pickle_str)

        # Uncompress the image from image_encode. 
        image = cv2.imdecode(image_encode, cv2.IMREAD_COLOR)

        # Feed the image to the model. 
        res_queue = self.pool.apply_async(feedImage, (image, ))

        # Get the result from result queue. 
        result = res_queue.get()

        # Package the result to pickle_str. 
        pickle_str = pickle.dumps(result)

        # Encode the pickle_str to base64 str for grpc transfer. 
        b64_str = base64.b64encode(pickle_str)

        #print('POOL complet a task in {:.5f} seconds.'.format(time() - start))

        return b64_str

'''
grpc Services for model process.
'''
class DnetPredict(data_pb2_grpc.DnetPredictServicer):
    def __init__(self, model_pool_size = 1, greedy = True):
        global logger_manager
        self.logger = logger_manager.get_logger('ModelServer')
        self.model_pool = ServerProcessPool(pool_size = model_pool_size, greedy = greedy)

    def dnet_detect(self, request, context):
        start = time()

        str = request.text        
        b64_str = self.model_pool.predictImage(str)
        self.logger.debug('Server complet a task in {:.5f} second. '.format(time() - start))
                      
        return data_pb2.Data(text = b64_str)
'''
Start the grpc server. 

port: 
    grpc server port.

model_pool_size: 
    how many process in the server pool to provide model service. 

send_msg_size: 
    The server sending message size. 
    It needs big enough to contain the prediction result from model service.

recv_msg_size:
    The server receiving message size. 
    It needs to has enough space for the image for model server prediction. 

greedy:
    If True, the model server processes will occupy one GPU as possible as it can before start it in other GPUs. 
    If False, the model server processes will be balance placed to each GPUs in the system.  
'''
def startServer(port = _PORT, 
                model_pool_size = 1,
                log_level = 'warning',
                send_msg_size = _SERVER_SEND_MSG_SIZE, 
                recv_msg_size = _SERVER_RECV_MSG_SIZE, 
                greedy = True):
    
    global logger_manager

    # Initilaize a LoggerManager
    logger_manager = loggerManager.LoggerManager(log_level = log_level)

    logger = logger_manager.get_logger('ModelServer')

    logger.info('Start model server. send_msg_size: {} / recv_msg_size: {}'.format(send_msg_size, recv_msg_size))

    serverOptions = [('grpc.max_send_message_length', send_msg_size),
                     ('grpc.max_receive_message_length', recv_msg_size)]
    grpcServer = grpc.server(futures.ThreadPoolExecutor(max_workers = model_pool_size * 2), options = serverOptions)
    data_pb2_grpc.add_DnetPredictServicer_to_server(DnetPredict(model_pool_size = model_pool_size, greedy = greedy), grpcServer)

    grpcServer.add_insecure_port('[::]:' + port)
    grpcServer.start()
    
    logger.warning('Model server started, port: {}, {} processes, greedy: {}'.format(port, model_pool_size, greedy))
    #print('Server Started: send_msg_size/recv_msg_size: {}/{}'.format(send_msg_size, recv_msg_size))

    try:
        while True:
            sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        logger.warning('Model Server Stop. ')
        #print("Stop the service. ") 
        grpcServer.stop(0)


#####################
# Client Part code. #
#####################

'''
Initialize process in client side, connect the grpc server.  
host: 
    grpc server host. 

port: 
    grpc server port. 

Return: 
    grpc client for client call. 
'''
def clientInit(host = _HOST, 
               port = _PORT, 
               send_msg_size = _SERVER_RECV_MSG_SIZE, 
               recv_msg_size = _SERVER_SEND_MSG_SIZE):
    clientOptions = [('grpc.max_send_message_length', send_msg_size), 
                     ('grpc.max_receive_message_length', recv_msg_size)]
    conn = grpc.insecure_channel(host + ':' + port, options = clientOptions)
    client = data_pb2_grpc.DnetPredictStub(channel = conn)
    #print('Creat client: send_msg_size/recv_msg_size: {}/{}'.format(send_msg_size, recv_msg_size))

    return client

'''
Send image to the model server for prediction. 
client: 
    grpc client from the clientInit()

image: 
    cv2 image that need to be sent to the model.

Return: 
    prediction result from the model. 
    In this darknet server it contains: out_boxes, out_scores, out_classes
'''
def clientDetect(client, image):
    img = cv2.imencode('.jpg', image)[1]
    pickle_str = pickle.dumps(img)
    message = base64.b64encode(pickle_str)
    #print('Send a image to model. ')
    response = client.dnet_detect(data_pb2.Data(text = message))
    result = response.text
    result = base64.b64decode(result)
    result = pickle.loads(result)
    #print('Received result. ', result)
    return result


if __name__ == '__main__':
    startServer()
