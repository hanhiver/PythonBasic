import colorsys
import os

from timeit import default_timer as timer 
from math import floor
from PIL import Image, ImageFont, ImageDraw
import numpy as np  


"""
MIN_DETECT_SCORE = 0.4 # The min score that consider the obj detected. 
HW_MIN_VALID_IOU = 0.7 # The min IOU that we consider the rect is not a new zone. 
HW_DECAY_VALUE_EACH_CYCLE = 0.6 # The decay value for each decay cycle. 
MAX_ACCURATE = 200.6 # The max of the accurate rate number. 
MAX_HITNUM = 300 # The max of the hit number of a hot zone. 
"""

"""
Class HW_rect to implement a rect. 
"""

class HW_rect(object):
	def __init__(self, left, top, right, bottom, 
				label = "", accuRate = 0.8, hitNum = 0, flag = 0):
		self.left = left
		self.top = top
		self.right = right
		self.bottom = bottom

		self.label = label
		self.accuRate = accuRate
		self.hitNum = hitNum
		self.flag = flag

		self.w = right - left
		self.h = bottom - top

		self.area = self.w * self.h

	def area(self):
		return self.area

"""
Function to caculate the IOU for two HW_rect
"""

def IOU(rect1, rect2):
	crossW = min(rect1.right, rect2.right) - max(rect1.left, rect2.left)
	crossH = min(rect1.bottom, rect2.bottom) - max(rect1.top, rect2.top)

	if crossW <=0 or crossH <=0:
		return .0
	
	cross = crossW * crossH

	return cross / (rect1.area + rect2.area - cross)

"""
Class HW_hotZones to implement hot zones in a certain 2d demention. 
"""

class HW_hotZones(object):
	
	options = {
		"MIN_DETECT_SCORE" : 0.4, # The min score that consider the obj detected. 
		"HW_MIN_VALID_IOU" : 0.7, # The min IOU that we consider the rect is not a new zone. 
		"HW_DECAY_VALUE_EACH_CYCLE" : 0.6, # The decay value for each decay cycle. 
		"MAX_ACCURATE" : 200.6, # The max of the accurate rate number. 
		"MAX_HITNUM" : 300, # The max of the hit number of a hot zone. 
	}

	@classmethod
	def getoptions(cls, n):
		if n in cls.options:
			return cls.options[n]
		else:
			return "Unrecognized attribute name '" + n + "'"

	def __init__(self, **kwargs):
		self.__dict__.update(self.options) # set up default values
		self.__dict__.update(kwargs) # and update with user overrides
		self.zones = []

	def _appendZone(self, rect):
		self.zones.append(rect)

	def _removeZone(self, rect):
		if rect in self.zones:
			self.zones.remove(rect)

	def _replaceZone(self, old, new):
		
		if old in self.zones:
			new.top = (new.top + old.top * 9) // 10
			new.bottom = (new.bottom + old.bottom * 9) // 10
			new.right = (new.right + old.right * 9) // 10
			new.left = (new.left + old.left * 9) // 10
			new.hitNum = old.hitNum
			new.accuRate = old.accuRate
			new.flag = old.flag
			self.zones.remove(old)

		self._appendZone(new)
		
		return new

	def findMaxIOU(self, rect, minAccuRate = 0):
		maxIOU = .0
		currRect = None

		for item in self.zones:
			if item.accuRate > minAccuRate:
				curIOU = IOU(item, rect)
				if curIOU > maxIOU:
					maxIOU = curIOU
					currRect = item

		return currRect, maxIOU

	def hotZoneDecay(self):
		for item in self.zones:
			item.accuRate -= self.HW_DECAY_VALUE_EACH_CYCLE
			item.hitNum -= 1
			#print("box label = {}, hitNum = {}, accuRate = {}".format(item.label, item.hitNum, item.accuRate))

		for item in self.zones:
			if item.accuRate < 0 or item.hitNum < 0:
				self.zones.remove(item)

	def mergeNewZone(self, rect, minScore = None):
		if minScore == None:
			minScore = self.MIN_DETECT_SCORE

		if rect.accuRate < minScore:
			return

		foundZone, maxIOU = self.findMaxIOU(rect)

		# If the maxIOU less than HW_MIN_VALID_IOU, 
		# consider the rect is a new zone and add it to zones. 
		if foundZone != None and maxIOU > self.HW_MIN_VALID_IOU:
			foundZone.accuRate += rect.accuRate * maxIOU * 2
			foundZone.hitNum += 3 * maxIOU * rect.accuRate
			if foundZone.hitNum > self.MAX_HITNUM:
				foundZone.hitNum = self.MAX_HITNUM
			if foundZone.accuRate > self.MAX_ACCURATE:
				foundZone.accuRate = self.MAX_ACCURATE
			self._replaceZone(foundZone, rect)
		else:
			self._appendZone(rect)

		#print("{} box in hotzone, maxIOU = {}".format(len(self.zones), maxIOU))


	def drawTags(self, image, color, minDrawAccuRate = 1, minTagAccuRate = 2):

		# Prepare the font and thickness to draw the tag. 
		font = ImageFont.truetype(font='font/FiraMono-Medium.otf',
			size=np.floor(3e-2 * image.size[1] + 0.5).astype('int32'))
		thickness = (image.size[0] + image.size[1]) // 400

		draw = ImageDraw.Draw(image)

		for item in self.zones:

			print("item.label = {}, item.accuRate = {}, color = {}".format(item.label, item.accuRate, color))

			if item.accuRate > minDrawAccuRate:

				# limit the tag within image. 
				label_size = draw.textsize(item.label, font)
				top = max(0, floor(item.top + 0.5))
				left = max(0, floor(item.left + 0.5))
				bottom = min(image.size[1], floor(item.bottom + 0.5))
				right = min(image.size[0], floor(item.right + 0.5))

				# draw the rect
				for i in range(thickness - 2):
					draw.rectangle([left + i, top + i, right - i, bottom - i], 
						outline = color)

			if item.accuRate > minTagAccuRate:

				# bold the rect and draw the tag. 
				for i in range(thickness + 2):
					#draw.rectangle([left + i, top + i, right - i, bottom - i], outline = color)
					draw.line((left + i, top, right + i, bottom), fill = color)
					draw.line((left + i, bottom, right + i, top), fill = color)

				if top - label_size[1] >= 0:
					text_origin = [left, top - label_size[1]]
				else:
					text_origin = [left, top + 1]

				#draw.rectangle([tuple(text_origin), tuple(text_origin + label_size)], fill = color)
				draw.text(text_origin, item.label, fill = color, font=font)

		del draw
		return image
























