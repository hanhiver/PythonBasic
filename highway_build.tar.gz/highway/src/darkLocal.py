
import colorsys
import os, sys, argparse, time
from timeit import default_timer as timer
from datetime import datetime

import numpy as np
from PIL import Image, ImageFont, ImageDraw

#import tensorflow as tf

import grpc

#import hwd.hotzone as hotzone 
#from hwd.hotzone import HW_hotZones

import hotzone
#from hotzone import HW_hotZones

#from darkServer import darkPool
import darkPool

import dnet

#from darkServer import loggerManager
import loggerManager

# Added for schedrun. 
import schedrun
import multiprocessing
import cv2
import queue

# Added by MINGLIANG
import mjpeg_stream

#HOST = '9.111.158.180'
HOST = 'localhost'
#HOST = '9.181.92.123'
PORT = '18501'

CLIENT_SEND_MSG_SIZE = 2000000
CLIENT_RECV_MSG_SIZE = 500000

SKIP_FRAME_NUM = 13 # Phase one frame per how many frames to increase the performance. 
RECORD_FRAMES_FOR_INCIDENCE = 200 # How many frames will be record for a incidence. 

VEHICLE_OBJS = ['car', 'bus', 'truck', 'train']
PERSON_OBJS = ['person']
MIN_STOPPING_HIT_NUMBER = 85 // SKIP_FRAME_NUM # The min hit number to consider a stopping obj. 

PRINT_HOTZONE_INFO = True # If print the hot zone information to the image for debug. 

hotZone_car = hotzone.HW_hotZones(MAX_HITNUM = hotzone.HW_hotZones.getoptions('MAX_HITNUM') // SKIP_FRAME_NUM, 
                                    MAX_ACCURATE = hotzone.HW_hotZones.getoptions('MAX_ACCURATE') // SKIP_FRAME_NUM)
hotZone_person = hotzone.HW_hotZones()

frame_index = 0
stub = None
class_names = None

draw_rect_list = []
draw_tag_list = [] 

frame_remained = 0

logger_manager = None
logger = None

stream_to_gui = None

def get_classes_and_colors():
    ''' Read the classess' name from the classes.txt file. '''
    with open('classes.txt') as f:
        class_names = f.readlines()
    class_names = [c.strip() for c in class_names]

    ''' Generate colors for drawing bounding boxes. '''
    hsv_tuples = [(x / len(class_names), 1., 1.)
                  for x in range(len(class_names))]
    colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
    colors = list(
        map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)), colors))
    np.random.seed(10101)  # Fixed seed for consistent colors across runs.
    np.random.shuffle(colors)  # Shuffle colors to decorrelate adjacent classes.
    np.random.seed(None)  # Reset seed to default.

    return class_names, colors 


# Draw a rectangle to all input_rects specified position. 
def draw_rect_to_image(image, input_rects, colors, thickness = None):
    draw = ImageDraw.Draw(image)

    # default color is write (0, 0, 0)
    # If there is no specified thickness, set a default one. 
    thickness = (image.size[0] + image.size[1]) // 500
    draw = ImageDraw.Draw(image)

    for item, color_cur in zip(input_rects, colors):
        # Make sure the rectangle will not out of the image. 
        top = max(0, np.floor(item.top + 0.5).astype('int32'))
        left = max(0, np.floor(item.left + 0.5).astype('int32'))
        bottom = min(image.size[1], np.floor(item.bottom + 0.5).astype('int32'))
        right = min(image.size[0], np.floor(item.right + 0.5).astype('int32'))

        for i in range(thickness):
            draw.rectangle([left + i, top - i, right - i, bottom + i], outline=color_cur)

    del draw
    return image 
        
# Draw a cross to all input_rects specified position and draw the lables of the input_rects. 
def draw_tag_to_image(image, input_rects, colors, thickness = None, font = None):
    draw = ImageDraw.Draw(image)

    # default color is write (0, 0, 0)
    # If there is no specified thickness, set a default one. 
    thickness = (image.size[0] + image.size[1]) // 300

    # if there is no specified font, set a default one. 
    if font == None:
        font = ImageFont.truetype(font = 'Courier.dfont', 
                              size = np.floor(image.size[1]/30 + 0.5).astype('int32'))

    for item, color_cur in zip(input_rects, colors):
        # Make sure the rectangle will not out of the image. 
        top = max(0, np.floor(item.top + 0.5).astype('int32'))
        left = max(0, np.floor(item.left + 0.5).astype('int32'))
        bottom = min(image.size[1], np.floor(item.bottom + 0.5).astype('int32'))
        right = min(image.size[0], np.floor(item.right + 0.5).astype('int32'))

        for i in range(thickness):
            draw.rectangle([left + i, top - i, right - i, bottom + i], outline = color_cur)
            draw.line((left + i, top, right - thickness + i, bottom), fill = color_cur)
            draw.line((left + i, bottom, right - thickness + i, top), fill = color_cur)

        label_size = draw.textsize(item.label, font)
        if top - label_size[1] >= 0:
            text_origin = np.array([left, top - label_size[1]])
        else:
            text_origin = np.array([left, top + 1])
        
        draw.rectangle( [tuple(text_origin), tuple(text_origin + label_size)], fill = color_cur)
        draw.text(text_origin, item.label, fill = (255, 255, 255), font = font)

    del draw
    return image 


def dpool_detect_car(client, image):

    global frame_index
    global draw_rect_list, draw_tag_list
    global class_names, colors
    global frame_remained
    global logger 

    start = timer()

    if frame_index % SKIP_FRAME_NUM == 0:
        if frame_index >= SKIP_FRAME_NUM:
            frame_index = 0
        
        logger.debug('Send a frame to model.')
        
        img = np.asarray(image)
        #out_boxes, out_scores, out_classes = dnet.dnet_detect_image(dnet.netMain, dnet.metaMain, img, thresh=.2)
        out_boxes, out_scores, out_classes = darkPool.clientDetect(client, img)
        logger.debug('Response from model server: found {} boxes in this frame.'.format(len(out_boxes)))

        draw_rect_list = []
        draw_tag_list = [] 

        for i, c in reversed(list(enumerate(out_classes))):
            #predicted_class = class_names[c]
            predicted_class = c 
            box = out_boxes[i]
            score = out_scores[i]

            label = '{} {:.2f}'.format(predicted_class, score)
            top, left, bottom, right = box

            if predicted_class in VEHICLE_OBJS:
                detect_zone = hotzone.HW_rect(left, top, right, bottom, label = label, accuRate = score)
                draw_rect_list.append([detect_zone, colors[i]])

                if (bottom - top > image.size[1] * 0.03) and (right - left > image.size[0] * 0.03):
                    rect, IOU = hotZone_car.findMaxIOU(detect_zone, minAccuRate = 3)
                    hotZone_car.mergeNewZone(detect_zone)
                    if IOU > hotZone_car.HW_MIN_VALID_IOU and rect.hitNum > MIN_STOPPING_HIT_NUMBER:
                        draw_tag_list.append([detect_zone, colors[i]])
                        # Set frame_remained to save the incident record. 
                        #frame_remained = 100 // SKIP_FRAME_NUM
                        frame_remained = RECORD_FRAMES_FOR_INCIDENCE

            elif predicted_class in PERSON_OBJS:
                detect_zone = hotzone.HW_rect(left, top, right, bottom, label = label, accuRate = score)
                draw_rect_list.append([detect_zone, colors[i]])

                rect, IOU = hotZone_person.findMaxIOU(detect_zone, minAccuRate = 0.2)
                hotZone_person.mergeNewZone(detect_zone)

                if score > 0.7:
                    draw_tag_list.append([detect_zone, colors[i]])
                    # Set frame_remained to save the incident record. 
                    #frame_remained = 100 // SKIP_FRAME_NUM
                    frame_remained = RECORD_FRAMES_FOR_INCIDENCE
        
        # Decay the accumulated values of the hotzones. 
        hotZone_car.hotZoneDecay()
        hotZone_person.hotZoneDecay()

    else:
        logger.debug('Skip a frame: {}'.format(frame_index))
        
    frame_index += 1
    font = ImageFont.truetype(font = 'font/FiraMono-Medium.otf', 
                              size = np.floor(image.size[1]/30 + 0.5).astype('int32'))

    # No mater if the fram skipped, print the same rects and tags. 
    draw_rect_to_image(image, [x[0] for x in draw_rect_list], [x[1] for x in draw_rect_list])
    draw_tag_to_image(image, [x[0] for x in draw_tag_list], [x[1] for x in draw_tag_list], font = font)

    if PRINT_HOTZONE_INFO:
        draw = ImageDraw.Draw(image)
        iniPos = np.array([0, image.size[1]*2//3])
        
        for item in hotZone_car.zones:
            printZones = '{} -- hit:({:.3f}), Rate:({:.3f})'.format(item.label, item.hitNum, item.accuRate)
            draw.text(iniPos, printZones, fill=(255, 255, 255), font=font)
            iniPos += np.array([0, 28])
        for item in hotZone_person.zones:
            printZones = '{} -- hit:({:.3f}), Rate:({:.3f})'.format(item.label, item.hitNum, item.accuRate)
            draw.text(iniPos, printZones, fill=(255, 255, 255), font=font)
            iniPos += np.array([0, 28])
        
        del draw

    end = timer()
    logger.debug('frame: {}, time: {}'.format(frame_index, (end - start)))
    return image 

def detect_video(video_path,  
                 output_path="", 
                 summary_file = None,
                 stream_port = None,
                 record_path = "",
                 camera_id = "",
                 model_host = 'localhost',
                 model_port = '18501',
                 local_view = False):
    global logger 

    import cv2
    vid = cv2.VideoCapture(video_path)

    logger.info('Open the video: {}'.format(video_path))

    if not vid.isOpened():
        logger.critical('Failed to open the video: {}.'.format(video_path))
        raise IOError("Couldn't open webcam or video")

    video_FourCC    = int(vid.get(cv2.CAP_PROP_FOURCC))
    video_fps       = vid.get(cv2.CAP_PROP_FPS)
    video_size      = (int(vid.get(cv2.CAP_PROP_FRAME_WIDTH)),
                        int(vid.get(cv2.CAP_PROP_FRAME_HEIGHT)))
    isOutput = True if output_path != "" else False
    if isOutput:
        video_FourCC = cv2.VideoWriter_fourcc(*'MP42')
        #print("!!! TYPE:", type(output_path), type(video_FourCC), type(video_fps), type(video_size))
        #print("!!! TYPE:", output_path, video_FourCC, video_fps, video_size)
        out = cv2.VideoWriter(output_path, video_FourCC, video_fps, video_size)
        logger.info('Output video: {}, format: {}, fps: {}, video size: {}'.format(
                    output_path, video_FourCC, video_fps, video_size))
    
    # isRecord: if record the incident to certain file. 
    # frame_remained: how many frames remained for incident recording.  
    isRecord = True if record_path != "" else False
    
    global frame_remained 
    frame_remained = 0
    record_out = None

    accum_time = 0
    curr_fps = 0
    accum_frame = 0
    run_time = []
    fps = "FPS: ??"
    prev_time = timer()
    
    if local_view:
        cv2.namedWindow("result", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("result", 640, 400)
        cv2.moveWindow("result", 100, 100)
        logger.info('Open the local view windows. ')

    # Initialize the Stream to send frame. 
    stream_to_gui = None
    if stream_port: 
        stream_to_gui = mjpeg_stream.Stream(camera_id, stream_port)
        logger.info('Initialize stream_to_gui, camera_id: {}, stream_port: {}'.format(
                    camera_id, stream_port))

    client = darkPool.clientInit(host = model_host, port = model_port, 
                                 send_msg_size = CLIENT_SEND_MSG_SIZE, 
                                 recv_msg_size = CLIENT_RECV_MSG_SIZE)
    logger.info('Connect to the model server: {}:{}, send_msg_size: {}, recv_msg_size: {}.'.format(
                model_host, model_port, CLIENT_SEND_MSG_SIZE, CLIENT_RECV_MSG_SIZE))

    while True:
        return_value, frame = vid.read()
        if type(frame) != type(None):
            #image = cv2.resize(frame, (416, 416), interpolation = cv2.INTER_LINEAR)
            image = Image.fromarray(frame)
            image = dpool_detect_car(client, image)
            result = np.asarray(image)

            # Send frame to GUI interface. 
            if stream_to_gui:
                stream_to_gui.send_frame(result)
                logger.debug('Send a frame to stream_to_gui. ')

            curr_time = timer()
            exec_time = curr_time - prev_time
            prev_time = curr_time
            accum_time = accum_time + exec_time
            run_time.append(exec_time)
            accum_frame = accum_frame + 1
            curr_fps = curr_fps + 1
            if accum_time > 1:
                accum_time = accum_time - 1
                fps = "FPS: " + str(curr_fps)
                curr_fps = 0

            #print('frame_remained: ', frame_remained, isRecord)
            if isRecord:
                logger.debug('{} frame remained in the reccord video. '.format(frame_remained))
                if frame_remained > 0:
                    if not record_out:

                        now = int(time.time())
                        time_array = time.localtime(now)
                        file_name = time.strftime('/Incident_%Y-%m-%d_%H-%M-%S.avi', time_array)
                        record_file = record_path + file_name
                        # Post alert to GUI. Modified by Mingliang. Add argument of file export name.
                        if stream_to_gui:
                            stream_to_gui.post_alert('Incident Found! ', record_file)
                        #video_FourCC = cv2.VideoWriter_fourcc(*'MP42')
                        record_out = cv2.VideoWriter(record_file, video_FourCC, video_fps, video_size)
                        logger.info('Create record file: {}'.format(record_file))

                    record_out.write(result)
                    logger.debug('Log a frame to record file: {}'.format(record_file))
                    #print('Incident Record: {}'.format(file_name))
                    frame_remained -= 1

                    if frame_remained == 0: 
                        record_out = None
                        logger.info('Record file {} finished. '.format(record_file))

            if local_view:
                cv2.putText(result, text=fps, org=(3, 15), fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                            fontScale=0.50, color=(255, 0, 0), thickness=2)
                cv2.imshow("result", result)
            
            if isOutput:
                out.write(result)

            if local_view:
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    logger.info('Aboard Keyborad instruction received, stop. ')
                    break
        else:
            break
    
    cv2.destroyAllWindows()

    sum_run_time = sum(run_time)
    print('run_time:', sum_run_time)
    print('accum_frame:', accum_frame)
    print('Average FPS = {}'.format(accum_frame / sum_run_time))
    
    if summary_file:
        with open(summary_file, 'w') as summary:
            summary.write('RUNTIME = {}, #Frame = {}, Average FPS = {}'.format(sum_run_time, accum_frame, accum_frame / sum_run_time))
            for item in run_time:
                summary.write(str(item) + '\n')

def init_show_windows(local_view, stream_port, camera_id):
    global logger 
    global stream_to_gui

    if local_view:
        cv2.namedWindow("result", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("result", 640, 400)
        cv2.moveWindow("result", 100, 100)

    if stream_port: 
        stream_to_gui = mjpeg_stream.Stream(camera_id, stream_port)
        logger.info('Initialize stream_to_gui, camera_id: {}, stream_port: {}'.format(
                    camera_id, stream_port))

    logger.info('Init show windows finished. ')

def show_frame(input_queue, local_view, stream_port, timeout = 3):
    global logger 
    global stream_to_gui

    #logger.info('Enter show_frame: local_view: {}, stream_port: {}'.format(local_view, 'None' if stream_port == '' else stream_port))

    try:
        frame = input_queue.get(timeout = timeout)
        if type(frame) == str:
            if stream_to_gui:
                stream_to_gui.post_alert('Incident Found! ', frame)
                logger.debug('Send alert to stream_to_gui, incident file: {}'.format(frame))

        else:
            if local_view: 
                cv2.imshow('result', frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    return False

            if stream_to_gui:
                stream_to_gui.send_frame(frame)
                logger.debug('Send a frame to stream_to_gui. ')

    except queue.Empty:
        print('Queue empty.')
        return False

    return True

def detect_video_smooth(video_path,  
                 output_path="", 
                 summary_file = None,
                 stream_port = None,
                 record_path = "",
                 camera_id = "",
                 model_host = 'localhost',
                 model_port = '18501',
                 local_view = False):
    global logger 
    global stream_to_gui

    if local_view or stream_port:
        frame_queue = multiprocessing.Queue()
        sched_run = schedrun.SchedRun(func = show_frame, args = (frame_queue, local_view, stream_port, ), 
                                      init_func = init_show_windows, init_args = (local_view, stream_port, camera_id, ), 
                                      interval = 0.04, 
                                      init_interval = 2)

    vid = cv2.VideoCapture(video_path)

    logger.info('Open the video: {}'.format(video_path))

    if not vid.isOpened():
        logger.critical('Failed to open the video: {}.'.format(video_path))
        raise IOError("Couldn't open webcam or video")

    video_FourCC    = int(vid.get(cv2.CAP_PROP_FOURCC))
    video_fps       = vid.get(cv2.CAP_PROP_FPS)
    video_size      = (int(vid.get(cv2.CAP_PROP_FRAME_WIDTH)),
                        int(vid.get(cv2.CAP_PROP_FRAME_HEIGHT)))
    isOutput = True if output_path != "" else False
    if isOutput:
        video_FourCC = cv2.VideoWriter_fourcc(*'mp4v')
        #print("!!! TYPE:", type(output_path), type(video_FourCC), type(video_fps), type(video_size))
        #print("!!! TYPE:", output_path, video_FourCC, video_fps, video_size)
        out = cv2.VideoWriter(output_path, video_FourCC, video_fps, video_size)
        logger.info('Output video: {}, format: {}, fps: {}, video size: {}'.format(
                    output_path, video_FourCC, video_fps, video_size))
    
    # isRecord: if record the incident to certain file. 
    # frame_remained: how many frames remained for incident recording.  
    isRecord = True if record_path != "" else False
    
    global frame_remained 
    frame_remained = 0
    record_out = None

    accum_time = 0
    curr_fps = 0
    accum_frame = 0
    run_time = []
    fps = "FPS: ??"
    prev_time = timer()

    client = darkPool.clientInit(host = model_host, port = model_port, 
                                 send_msg_size = CLIENT_SEND_MSG_SIZE, 
                                 recv_msg_size = CLIENT_RECV_MSG_SIZE)
    logger.info('Connect to the model server: {}:{}, send_msg_size: {}, recv_msg_size: {}.'.format(
                model_host, model_port, CLIENT_SEND_MSG_SIZE, CLIENT_RECV_MSG_SIZE))

    while True:
        try:
            return_value, frame = vid.read()
        except EOFError:
            logger.error('End of the input file.')
            break

        if type(frame) != type(None):
            #image = cv2.resize(frame, (416, 416), interpolation = cv2.INTER_LINEAR)
            image = Image.fromarray(frame)
            image = dpool_detect_car(client, image)
            result = np.asarray(image)

            curr_time = timer()
            exec_time = curr_time - prev_time
            prev_time = curr_time
            accum_time = accum_time + exec_time
            run_time.append(exec_time)
            accum_frame = accum_frame + 1
            curr_fps = curr_fps + 1
            if accum_time > 1:
                accum_time = accum_time - 1
                fps = "FPS: " + str(curr_fps)
                curr_fps = 0

            #print('frame_remained: ', frame_remained, isRecord)
            if isRecord:
                logger.debug('{} frame remained in the reccord video. '.format(frame_remained))
                if frame_remained > 0:
                    if not record_out:

                        now = datetime.now()
                        now_str = now.strftime('%Y-%m-%d_%H_%M_%S')
                        base_name = 'incident_cam-%s_%s.mp4' % (str(camera_id), now_str)
                        record_file = os.path.join(record_path, base_name)

                        # Post alert to GUI. 
                        if stream_port:
                            logger.debug('Incident Found!')
                            frame_queue.put(base_name)

                        video_FourCC = cv2.VideoWriter_fourcc(*'avc1')
                        record_out = cv2.VideoWriter(record_file, video_FourCC, video_fps, video_size)
                        logger.info('Create record file: {}'.format(record_file))

                    record_out.write(result)
                    logger.debug('Log a frame to record file: {}'.format(record_file))
                    #print('Incident Record: {}'.format(file_name))
                    frame_remained -= 1

                    if frame_remained == 0: 
                        record_out = None
                        logger.info('Record file {} finished. '.format(record_file))

            if local_view or stream_port:
                cv2.putText(result, text=fps, org=(3, 30), fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                            fontScale=0.8, color=(255, 255, 255), thickness=2)
                #cv2.imshow("result", result)
                frame_queue.put(result)
            
            if isOutput:
                out.write(result)

        else:
            break
    
    cv2.destroyAllWindows()

    sum_run_time = sum(run_time)
    print('run_time:', sum_run_time)
    print('accum_frame:', accum_frame)
    print('Average FPS = {}'.format(accum_frame / sum_run_time))
    
    if summary_file:
        with open(summary_file, 'w') as summary:
            summary.write('RUNTIME = {}, #Frame = {}, Average FPS = {}'.format(sum_run_time, accum_frame, accum_frame / sum_run_time))
            for item in run_time:
                summary.write(str(item) + '\n')


def main():
#if __name__ == '__main__':
    global logger_manager
    global logger 
    global class_names
    global colors

    parser = argparse.ArgumentParser()

    parser.add_argument('-m', '--model', type = str, default = 'high_way_detector', 
                        help = 'Model name in the TF serving side. DEFAULT: high_way_detector')

    parser.add_argument('-u', '--url', type = str, default = 'localhost:8500', 
                        help = 'URL to the TF gRPC service address. DEFAULT: localhost:8500')

    parser.add_argument('-i', '--input', type = str, default = 'test.mp4', 
                        help = 'Input video. DEFAULT: test.mp4 ')

    parser.add_argument('-o', '--output', type = str, default = '', 
                        help = '[Optional] Output video. ')
    
    parser.add_argument('-l', '--loglevel', type = str, default = 'warning',
                        help = '[Optional] Log level. WARNING is default. ')

    parser.add_argument('-s', '--summary', type = str, default = '',
                        help = '[Optional] Log the fps information. ')

    parser.add_argument('-r', '--recordpath', type = str, default = '', 
                        help = '[Optional] Folder to save the record of incident. ')

    parser.add_argument('-mh', '--modelhost', type = str, default = '', 
                        help = '[Optional] Host of the model server. ')

    parser.add_argument('-mp', '--modelport', type = str, default = '', 
                        help = '[Optional] Port number of the model server. ')  

    parser.add_argument('-lv', '--localview', default = False, action="store_true",
                        help = '[Optional] If shows result to local view. ')    

    # Following two lines added by Mingliang
    parser.add_argument('-n', '--cnumber', type = str, default = '',
                        help = '[Optional] Camera ID (set by GUI). ')

    parser.add_argument('-p', '--port', type = str, default = '',
                        help = '[Optional] Port number to the GUI interface. ')

    parser.add_argument('-t', '--tag', type = str, default = '',
                        help = '[Optional] Tag to recognize the process. ')

    FLAGS = parser.parse_args()

    logger_manager = loggerManager.LoggerManager(log_level = FLAGS.loglevel)
    logger = logger_manager.get_logger('Mainfunc')

    log_str = 'Camera {} Started. Connect to the model server: {}:{}.'.format(
                FLAGS.cnumber, FLAGS.modelhost, FLAGS.modelport)
    logger.info(log_str)

    if 'input' in FLAGS:
        class_names, colors = get_classes_and_colors()

        #detect_video(FLAGS.input,  
        detect_video_smooth(FLAGS.input,  
                     output_path = FLAGS.output, 
                     summary_file = FLAGS.summary,
                     stream_port = FLAGS.port,
                     camera_id = FLAGS.cnumber,
                     record_path = FLAGS.recordpath,
                     model_host = FLAGS.modelhost,
                     model_port = FLAGS.modelport,
                     local_view = FLAGS.localview)

    else:
        print("See usage with --help.")

if __name__ == '__main__':
    main()



