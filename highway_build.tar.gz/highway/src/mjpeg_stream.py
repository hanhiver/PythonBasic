# coding:utf-8

import logging
import numpy as np
import cv2
from django.conf import settings
import base64
import zmq
import os
import requests
import urllib3

FORMAT = '%(asctime)-15s %(levelname)s %(message)s'
logging.basicConfig(format = FORMAT)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

"""
Requirements:
    opencv-python
    pyzmq
    numpy

Usage:
1. Initialize the Stream() object, only once at the front of your python script:
    stream = Stream(cam_id, port)

2. In a the loop, send a processed frame:
    stream.send_frame(frame)  # frame is numpy.ndarray

3. If an abnormal behavior is detected, post an alert message to the portal:
    stream.post_alert(message)

"""


class Stream():
    port = -1
    cam_id = -1
    socket = None
    tmpdir = ''
    tmpfile = ''

    def __init__(self, cam_id, port = -1):
        try:
            self.cam_id = int(cam_id)
            self.port = int(port)
        except Exception as error:
            raise error

        context = zmq.Context()
        self.socket = context.socket(zmq.PUB)
        port = self.socket.bind_to_random_port('tcp://*', max_tries = 10)
        if port < 0:
            logger.error('mjpeg_stream.Stream: Cannot open bind to any TCP port in Stream()')
        self.set_env()  # TODO: error handling
        self.set_cam_port(port)

    def send_frame(self, frame):
        """Send a frame to the stream for web portal to read.

        Args:
            frame (numpy.ndarray): A frame that is processed by the beckend.

        Returns:
            None. This method doesn't return value.
        """
        height, width = frame.shape[:2]
        frame = cv2.resize(frame, (int(width * 0.3), int(height * 0.3)), interpolation = cv2.INTER_AREA)

        cv2.imwrite(self.tmpfile, frame)
        with open(self.tmpfile, "rb") as f:
            image = f.read()
            f.close()
        # encoded, buffer = cv2.imencode('.jpg', frame)
        jpeg_as_text = base64.b64encode(image)
        self.socket.send(jpeg_as_text)

    def post_alert(self, message):
        """Post an alert message if an abnormal behavior is detected on a given camera. This method does not block.

        Args:
            message (str): the message being showing in the portal which indicates an abnormal behavior on the given camera.

        Returns:
            None. This method doesn't return value.

        """
        self.post(op = 'post_alert', message = message)

    def set_cam_port(self, port):
        self.post(op = 'set_cam_port', message = '', args = {'port': port})

    def post(self, op, message, args = {}):
        url = 'http://localhost:8000/%s/' % op
        data = {
            'cam_id': self.cam_id,
            'msg': message
        }
        data = {**data, **args}
        http = urllib3.PoolManager()
        http.request('POST', url, fields = data)

    def set_env(self):
        top = '/tmp/highway_tmp/stream'
        if not os.path.exists(top):
            try:
                os.makedirs(top, exist_ok = True)
            except Exception as error:
                logger.error('mjpeg_stream.Stream.set_env(): failed to create directory %s: %s' % (top, str(error)))
                return False

        self.tmpdir = os.path.join(top, 'cam%d' % (self.cam_id))
        if not os.path.exists(self.tmpdir):
            try:
                os.mkdir(self.tmpdir)
            except Exception as error:
                logger.error('mjpeg_stream.Stream.set_env(): failed to create directory %s: %s' % (self.tmpdir, str(error)))
                return False
        self.tmpfile = os.path.join(self.tmpdir, '%d_%d.jpeg' % (self.cam_id, self.port))
        return True
