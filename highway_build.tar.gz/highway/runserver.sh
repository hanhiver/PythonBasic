#!/bin/bash

python3 server.py >> log.txt 2>&1
