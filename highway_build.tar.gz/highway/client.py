import darkLocal

if __name__ == '__main__':
    darkLocal.main()

